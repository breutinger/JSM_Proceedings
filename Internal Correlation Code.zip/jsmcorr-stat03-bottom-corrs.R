#### Metadata ####

# Code written by: Nicholas Bussberg
# Last Update: 2024-10-05
# Filename: jsmcorr-stat03-bottom-corrs.R

# Purpose of this script:
    # Plot correlations of cores with climate variables.
    # Look at weakest correlations among trees


#### Setup ####

rm(list=ls())
options(width = 80)

filename <-"jsmcorr-stat03-bottom-corrs"

sink(paste(filename, ".log", sep = "")) # create log file to store output

# R version
R.version.string


#### Project Code ####

## 0 Load data, check metadata, and load packages

all.corrs <- readRDS("Data/jsmcorr-data02-correlations.RDS")
comment(all.corrs)

library(dplyr)

all.corrs2 <- all.corrs[all.corrs$`Corr A-B` < 0.4 & 
                          all.corrs$`Corr A-B` > 0, ]


## 1 Make summary stats table

corr.vars <- names(all.corrs2[ ,4:12])
corr.sum.stats <- matrix(data=NA, nrow=(length(all.corrs2[, 4:12])+1), 
                         ncol=7)
corr.sum.stats[1, ] <- c("Variable", "n", "Mean", "SD", "Median", "Min", "Max")

for(var in 1:length(all.corrs2[, 4:12])){
  corr.index <- var+3
  corr.sum.stats[(var+1), ] <- c(corr.vars[var], length(all.corrs2$State), 
                                 round(mean(all.corrs2[, corr.index], 
                                            na.rm = T), digits = 4), 
                                 round(sd(all.corrs2[, corr.index]), digits = 4), 
                                 median(all.corrs2[, corr.index]),
                                 min(all.corrs2[, corr.index]),
                                 max(all.corrs2[, corr.index]))
}

corr.sum.stats



all.corrs.trim <- all.corrs2[all.corrs2$`Corr A-B`>0, ]

all.corrs.condense1 <- all.corrs.trim[, c(1:2, 5, 7)]
all.corrs.condense2 <- all.corrs.trim[, c(1, 3, 6, 8)]
names(all.corrs.condense1) <- names(all.corrs.condense2) <- 
  c("State", "Core", "Corr w temp", "Corr w precip")

all.corrs.condense <- rbind(all.corrs.condense1, all.corrs.condense2)

length(all.corrs.condense[,1])

summary(all.corrs.condense$`Corr w temp`)
sd(all.corrs.condense$`Corr w temp`)

summary(all.corrs.condense$`Corr w precip`)
sd(all.corrs.condense$`Corr w precip`)




## 2 Make histogram and boxplot for each variable

for(var in 1:length(all.corrs2[, 4:12])){
  corr.index <- var+3
  
  pdf(file=paste("Graphs/", filename, "-hist", corr.vars[var], ".pdf", sep=""))
    hist(all.corrs2[, corr.index], 
         main = paste("Histogram: ", corr.vars[var], sep = ""))
  dev.off()
  
  pdf(file=paste("Graphs/", filename, "-sbsBox", corr.vars[var], ".pdf", sep=""))
    boxplot(all.corrs2[, corr.index] ~ all.corrs2$State, 
            main = paste("Boxplot by State: ", corr.vars[var], sep = ""))  
  dev.off()
}


pdf(file=paste("Graphs/", filename, "-hist-condensed-temp.pdf", sep=""))
hist(all.corrs.condense$`Corr w temp`)
dev.off()

boxplot(all.corrs.condense$`Corr w temp` ~ all.corrs.condense$State)

pdf(file=paste("Graphs/", filename, "-hist-condensed-precip.pdf", sep=""))
hist(all.corrs.condense$`Corr w precip`)
dev.off()

pdf(file=paste("Graphs/", filename, "-sbsBox-condensed-precip.pdf", sep=""))
boxplot(all.corrs.condense$`Corr w precip` ~ all.corrs.condense$State)
dev.off()



# close log
sink()



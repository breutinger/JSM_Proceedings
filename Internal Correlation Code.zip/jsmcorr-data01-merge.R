#### Metadata ####

# Code written by: Nicholas Bussberg
# Last Update: 2024-10-05
# Filename: jsmcorr-data01-merge.R

# Purpose of this script:
    #  Load each tree-ring and climate dataset and merge in less files


#### Setup ####

rm(list=ls())
options(width = 80)

filename <-"jsmcorr-data01-merge"

sink(paste(filename, ".log", sep = "")) # create log file to store output

# R version
R.version.string


#### Project Code ####

## 0 Load data and check metadata

library(dplR)

ia.rings <- read.rwl("Data/ia037.rwl")
ia.climate <- read.csv(file="Data/PRISM_ppt_tmean_stable_4km_1895_2022_42.6200_-91.1200.csv", 
                       fileEncoding = "UTF-8-BOM", skip = 10)

il.rings <- read.rwl("Data/il028.rwl")
il.climate <- read.csv(file="Data/PRISM_ppt_tmean_stable_4km_1895_2022_38.3550_-87.8233.csv", 
                       fileEncoding = "UTF-8-BOM", skip = 10)

in.rings <- read.rwl("Data/in019.rwl")
in.climate <- read.csv(file="Data/PRISM_ppt_tmean_stable_4km_1895_2022_39.2361_-86.2204.csv", 
                       fileEncoding = "UTF-8-BOM", skip = 10)

mo.rings <- read.rwl("Data/mo078.rwl")
mo.climate <- read.csv(file="Data/PRISM_ppt_tmean_stable_4km_1895_2022_38.6200_-90.6947.csv",
                       fileEncoding = "UTF-8-BOM", skip = 10)

nc.rings <- read.rwl("Data/nc023.rwl")
nc.climate <- read.csv(file="Data/PRISM_ppt_tmean_stable_4km_1895_2022_35.0300_-83.2600.csv",
                       fileEncoding = "UTF-8-BOM", skip = 10)

ny.rings <- read.rwl("Data/ny016.rwl")
ny.climate <- read.csv(file="Data/PRISM_ppt_tmean_stable_4km_1895_2022_43.0900_-73.3900.csv",
                       fileEncoding = "UTF-8-BOM", skip = 10)

oh.rings <- read.rwl("Data/oh007.rwl")
oh.climate <- read.csv(file="Data/PRISM_ppt_tmean_stable_4km_1895_2022_40.8800_-81.7500.csv",
                       fileEncoding = "UTF-8-BOM", skip = 10)

wi.rings <- read.rwl("Data/wi019.rwl")
wi.climate <- read.csv(file="Data/PRISM_ppt_tmean_stable_4km_1895_2022_42.8240_-89.9290.csv",
                       fileEncoding = "UTF-8-BOM", skip = 10)


## 1 Merge tree-ring and climate data for each state

# Iowa
ia.rings2 <- cbind(ia.rings, "Date"=as.numeric(rownames(ia.rings))) # add year 
ia.full <- merge(ia.rings2, ia.climate, by = "Date", all.x=T)
names(ia.full)[names(ia.full)=="tmean..degrees.F."] <- "tmean"
names(ia.full)[names(ia.full)=="ppt..inches."] <- "ppt"
comment(ia.full) <- paste("IA cores & climate data / ", filename, 
                          "/ NWB / 2024-10-05", sep = "")

# Illinois - need to remove 1 tree with only one core
il.rings2 <- cbind(il.rings, "Date"=as.numeric(rownames(il.rings))) # add year 
il.full <- merge(il.rings2, il.climate, by = "Date", all.x=T)
il.drop <- c("BLW24")
il.full2 <- il.full[, !(names(il.full) %in% il.drop)]
names(il.full2)[names(il.full2)=="tmean..degrees.F."] <- "tmean"
names(il.full2)[names(il.full2)=="ppt..inches."] <- "ppt"
comment(il.full2) <- paste("IL cores & climate data / ", filename, 
                           "/ NWB / 2024-10-05", sep = "")

# Indiana
in.rings2 <- cbind(in.rings, "Date"=as.numeric(rownames(in.rings))) # add year 
in.full <- merge(in.rings2, in.climate, by = "Date", all.x=T)
names(in.full)[names(in.full)=="tmean..degrees.F."] <- "tmean"
names(in.full)[names(in.full)=="ppt..inches."] <- "ppt"
comment(in.full) <- paste("IN cores & climate data / ", filename, 
                          "/ NWB / 2024-10-05", sep = "")

# Missouri - need to remove 3 trees with only one core
mo.rings2 <- cbind(mo.rings, "Date"=as.numeric(rownames(mo.rings))) # add year 
mo.full <- merge(mo.rings2, mo.climate, by = "Date", all.x=T)
mo.drop <- c("BAB151", "SBA01B", "SBA09A")
mo.full2 <- mo.full[, !(names(mo.full) %in% mo.drop)]
names(mo.full2)[names(mo.full2)=="tmean..degrees.F."] <- "tmean"
names(mo.full2)[names(mo.full2)=="ppt..inches."] <- "ppt"
comment(mo.full2) <- paste("MO cores & climate data / ", filename, 
                           "/ NWB / 2024-10-05", sep = "")

# North Carolina - need to remove 5 trees with only one core 
  # Also remove the third core for UMD06
nc.rings2 <- cbind(nc.rings, "Date"=as.numeric(rownames(nc.rings))) # add year 
nc.full <- merge(nc.rings2, nc.climate, by = "Date", all.x=T)
nc.full2 <- subset(nc.full, select = -c(UMD05a, UMD06c, UMD07b, UMD10a, UMD14a,
                                        UMD15a))
names(nc.full2)[names(nc.full2)=="tmean..degrees.F."] <- "tmean"
names(nc.full2)[names(nc.full2)=="ppt..inches."] <- "ppt"
comment(nc.full2) <- paste("NC cores & climate data / ", filename, 
                          "/ NWB / 2024-10-05", sep = "")

# New York - need to remove 6 trees with only one core
ny.rings2 <- cbind(ny.rings, "Date"=as.numeric(rownames(ny.rings))) # add year 
ny.full <- merge(ny.rings2, ny.climate, by = "Date", all.x=T)
ny.drop <- c("TVW05a", "TVW08a", "TVW13a", "TVW14a", "TVW15a", "TVW20a")
ny.full2 <- ny.full[, !(names(ny.full) %in% ny.drop)]
names(ny.full2)[names(ny.full2)=="tmean..degrees.F."] <- "tmean"
names(ny.full2)[names(ny.full2)=="ppt..inches."] <- "ppt"
comment(ny.full2) <- paste("NY cores & climate data / ", filename, 
                           "/ NWB / 2024-10-05", sep = "")

# Ohio - need to remove 4 trees with only one core
oh.rings2 <- cbind(oh.rings, "Date"=as.numeric(rownames(oh.rings))) # add year 
oh.full <- merge(oh.rings2, oh.climate, by = "Date", all.x=T)
oh.drop <- c("124091", "124111", "124132", "124212")
oh.full2 <- oh.full[, !(names(oh.full) %in% oh.drop)]
names(oh.full2)[names(oh.full2)=="tmean..degrees.F."] <- "tmean"
names(oh.full2)[names(oh.full2)=="ppt..inches."] <- "ppt"
comment(oh.full2) <- paste("OH cores & climate data / ", filename, 
                          "/ NWB / 2024-10-05", sep = "")

# Wisconsin
wi.rings2 <- cbind(wi.rings, "Date"=as.numeric(rownames(wi.rings))) # add year 
wi.full <- merge(wi.rings2, wi.climate, by = "Date", all.x=T)
names(wi.full)[names(wi.full)=="tmean..degrees.F."] <- "tmean"
names(wi.full)[names(wi.full)=="ppt..inches."] <- "ppt"
comment(wi.full) <- paste("WI cores & climate data / ", filename, 
                          "/ NWB / 2024-10-05", sep = "")



## 2 Save the data

saveRDS(ia.full,  "Data/jsmcorr-data01-ia.RDS")
saveRDS(il.full2, "Data/jsmcorr-data01-il.RDS")
saveRDS(in.full,  "Data/jsmcorr-data01-in.RDS")
saveRDS(mo.full2, "Data/jsmcorr-data01-mo.RDS")
saveRDS(nc.full2, "Data/jsmcorr-data01-nc.RDS")
saveRDS(ny.full2, "Data/jsmcorr-data01-ny.RDS")
saveRDS(oh.full2, "Data/jsmcorr-data01-oh.RDS")
saveRDS(wi.full,  "Data/jsmcorr-data01-wi.RDS")



# close log
sink()



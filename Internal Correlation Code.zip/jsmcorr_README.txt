### README for JSM Manuscript (internal correlation portion) Code ###

This file provides instructions on how to reproduce the internal correlation results in the associated manuscript. 


## Directory Requirements ##

1. All R scripts should be placed in the same working directory
2. Working directory should be set prior to running the code
3. The 8 .rwl files (tree core datasets from ITRDB) and 8 corresponding climate .csv files should be placed in a subfolder named "Data". 
	- Subfolder should be at the directory level as the R scripts.
	- Other datasets made by scripts (data01 and data02) will be placed in this folder
4. An empty subfolder named "Graphs" should be created to store the graphics 


## Software and Package Requirements ##

The packages �dplR� and �dplyr� are required to run theses scripts.


## Data Information ##

Tree-ring data were downloaded from the International Tree-Ring Data Bank (ITRDB): https://www.ncei.noaa.gov/products/paleoclimatology/tree-ring.

Climate data were downloaded from PRISM: https://prism.oregonstate.edu/explorer/


## Scripts and Code Execution ##

The code will run start to finish in alpha-numeric order. Note that when each file is Sourced with Echo in R, the file will generate an txt file with the extension .log. These files simply capture the input and output using the sink() function in R. 

Here is the list of scripts (in run order) and what they do. 

	1. jsmcorr-data01-merge.R: merges tree core data with climate data.

	2. jsmcorr-data02-correlations.R: calculates correlations of tree cores within a tree and tree cores against climate variables.

	3. jsmcorr-stat01-all-corrs.R: creates graphs to visualize correlations for all cores in the combined dataset from data02.

	4. jsmcorr-stat02-top-corrs.R: creates graphs to visualize correlations for only cores from high internally correlated (r>0.8) trees in the combined dataset from data02.

	5. jsmcorr-stat03-bottom-corrs.R: creates graphs to visualize correlations for only cores from weakly internally correlated (r<0.4) trees in the combined dataset from data02.
	


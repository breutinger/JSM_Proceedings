#### Metadata ####

# Code written by: Nicholas Bussberg
# Last Update: 2024-10-05
# Filename: jsmcorr-data02-correlations.R

# Purpose of this script:
    #  Compute correlations for cores with climate


#### Setup ####

rm(list=ls())
options(width = 80)

filename <-"jsmcorr-data02-correlations"

sink(paste(filename, ".log", sep = "")) # create log file to store output

# R version
R.version.string


#### Project Code ####

## 0 Load data and check metadata

ia.data <- readRDS("Data/jsmcorr-data01-ia.RDS")
il.data <- readRDS("Data/jsmcorr-data01-il.RDS")
in.data <- readRDS("Data/jsmcorr-data01-in.RDS")
mo.data <- readRDS("Data/jsmcorr-data01-mo.RDS")
nc.data <- readRDS("Data/jsmcorr-data01-nc.RDS")
ny.data <- readRDS("Data/jsmcorr-data01-ny.RDS")
oh.data <- readRDS("Data/jsmcorr-data01-oh.RDS")
wi.data <- readRDS("Data/jsmcorr-data01-wi.RDS")


## 1 Create function to calculate correlations

pairwise.corr <- function(coreA, coreB, tmean, ppt){
  # coreA and coreB: vectors of tree cores to compare
  # tmean: vector of mean annual temperatures 
  # ppt: vector of annual precipitation
  
  corr.AB <- cor(coreA, coreB, use = "pairwise.complete.obs")
  corr.At <- cor(coreA, tmean, use = "pairwise.complete.obs")
  corr.Bt <- cor(coreB, tmean, use = "pairwise.complete.obs")
  corr.Ap <- cor(coreA, ppt, use = "pairwise.complete.obs")
  corr.Bp <- cor(coreB, ppt, use = "pairwise.complete.obs")
  corr.all.ABt <- cor(rowMeans(cbind(coreA, coreB), na.rm = F), tmean, 
                      use = "pairwise.complete.obs")
  corr.all.ABt.rmna <- cor(rowMeans(cbind(coreA, coreB), na.rm = T), tmean, 
                           use = "pairwise.complete.obs")
  corr.all.ABp <- cor(rowMeans(cbind(coreA, coreB), na.rm = F), ppt, 
                      use = "pairwise.complete.obs")
  corr.all.ABp.rmna <- cor(rowMeans(cbind(coreA, coreB), na.rm = T), ppt, 
                           use = "pairwise.complete.obs")
  
  all.corrs <- c(corr.AB, corr.At, corr.Bt, corr.Ap, corr.Bp, 
                 corr.all.ABt, corr.all.ABt.rmna, 
                 corr.all.ABp, corr.all.ABp.rmna)
  return(all.corrs)
}


## 2 Set up data frames to store results

ia.corrs <- il.corrs <- in.corrs <- mo.corrs <- nc.corrs <- 
  ny.corrs <- oh.corrs <- wi.corrs <- 
  as.data.frame(matrix(data = NA, ncol=12))

names(ia.corrs) <- names(il.corrs) <- names(in.corrs) <- names(mo.corrs) <- 
  names(nc.corrs) <- names(ny.corrs) <- names(oh.corrs) <- names(wi.corrs) <- 
  c("State", "Core A", "Core B", "Corr A-B", "Corr A-t", "Corr B-t", 
    "Corr A-p", "Corr B-p", "Corr AB-t", "Corr AB.rmna-t", 
    "Corr AB-p", "Corr AB.rmna-p")



## 3 Wisconsin

wi.pairs <- matrix(data = c("BRM001A", "BRM001B",
                            "BRM002A", "BRM002B",
                            "BRM003A", "BRM003B",
                            "BRM005A", "BRM005B",
                            "BRM006A", "BRM006B",
                            "BRM007A", "BRM007B"), 
                   ncol = 2, byrow = T)

attach(wi.data)

for(core in 1:length(wi.pairs[,1])){
  wi.corrs[core, ] <- c("WI", wi.pairs[core, 1], wi.pairs[core, 2],
                        round(pairwise.corr(wi.data[, wi.pairs[core,1]], 
                                      wi.data[, wi.pairs[core,2]], 
                                      tmean, ppt), digits = 4))
}

detach(wi.data)




## 4 Indiana

in.pairs <- matrix(data = c("LDA01A", "LDA01B",
                            "LDA02A", "LDA02B",
                            "LDA03A", "LDA03B",
                            "LDA04A", "LDA04B",
                            "LDA05A", "LDA05B",
                            "LDA06A", "LDA06B",
                            "LDA07A", "LDA07B",
                            "LDA08A", "LDA08B",
                            "LDA09A", "LDA09B",
                            "LDA10A", "LDA10B"), 
                   ncol = 2, byrow = T)

attach(in.data)

for(core in 1:length(in.pairs[,1])){
  in.corrs[core, ] <- c("IN", in.pairs[core, 1], in.pairs[core, 2],
                        round(pairwise.corr(in.data[, in.pairs[core,1]], 
                                            in.data[, in.pairs[core,2]], 
                                            tmean, ppt), digits = 4))
}

detach(in.data)




## 5 North Carolina

nc.pairs <- matrix(data = c("UMD01a", "UMD01b",
                            "UMD02a", "UMD02b",
                            "UMD03a", "UMD03b",
                            "UMD04a", "UMD04b",
                            "UMD06a", "UMD06b",
                            "UMD08a", "UMD08b",
                            "UMD09a", "UMD09b",
                            "UMD16a", "UMD16b",
                            "UMD18a", "UMD18b",
                            "UMD20a", "UMD20b",
                            "UMD21a", "UMD21b"), 
                   ncol = 2, byrow = T)

attach(nc.data)

for(core in 1:length(nc.pairs[,1])){
  nc.corrs[core, ] <- c("NC", nc.pairs[core, 1], nc.pairs[core, 2],
                        round(pairwise.corr(nc.data[, nc.pairs[core,1]], 
                                            nc.data[, nc.pairs[core,2]], 
                                            tmean, ppt), digits = 4))
}

detach(nc.data)



## 6 Ohio

oh.pairs <- matrix(data = c("AJW01A", "AJW01B",
                            "AJW02A", "AJW02B",
                            "AJW03A", "AJW03B",
                            "AJW05A", "AJW05B",
                            "AJW06A", "AJW06B",
                            "AJW07A", "AJW07B",
                            "AJW08A", "AJW08B",
                            "AJW09A", "AJW09B",
                            "AJW10A", "AJW10B",
                            "AJW11A", "AJW11B",
                            "AJW12A", "AJW12B",
                            "AJW14A", "AJW14B",
                            "AJW15A", "AJW15B",
                            "AJW16A", "AJW16B",
                            "AJW17A", "AJW17B",
                            "AJW18A", "AJW18B",
                            "AJW19A", "AJW19B",
                            "AJW20A", "AJW20B"),
                            # "124011", "124012",
                            # "124021", "124022",
                            # "124031", "124032",
                            # "124041", "124042",
                            # "124051", "124052",
                            # "124061", "124062",
                            # "124071", "124072",
                            # "124081", "124082",
                            # "124121", "124122",
                            # "124141", "124142",
                            # "124151", "124152",
                            # "124161", "124162",
                            # "124181", "124182",
                            # "124221", "124222",
                            # "124231", "124232",
                            # "124241", "124242",
                            # "124251", "124252",
                            # "124261", "124262"), 
                   ncol = 2, byrow = T)

attach(oh.data)

for(core in 1:length(oh.pairs[,1])){
  oh.corrs[core, ] <- c("OH", oh.pairs[core, 1], oh.pairs[core, 2],
                        round(pairwise.corr(oh.data[, oh.pairs[core,1]], 
                                            oh.data[, oh.pairs[core,2]], 
                                            tmean, ppt), digits = 4))
}

detach(oh.data)



## 7 Iowa

ia.pairs <- matrix(data = c("WPH001a", "WPH001b",
                            "WPH002A", "WPH002B",
                            "WPH003A", "WPH003B",
                            "WPH101A", "WPH101B",
                            "WPH102A", "WPH102B",
                            "WPH103A", "WPH103B",
                            "WPH104A", "WPH104B",
                            "WPH201a", "WPH201b",
                            "WPH202A", "WPH202B",
                            "WPH302A", "WPH302B",
                            "WPH303A", "WPH303B"), 
                   ncol = 2, byrow = T)

attach(ia.data)

for(core in 1:length(ia.pairs[,1])){
  ia.corrs[core, ] <- c("IA", ia.pairs[core, 1], ia.pairs[core, 2],
                        round(pairwise.corr(ia.data[, ia.pairs[core,1]], 
                                            ia.data[, ia.pairs[core,2]], 
                                            tmean, ppt), digits = 4))
}

detach(ia.data)



## 8 Illinois

il.pairs <- matrix(data = c("BLW01A", "BLW01B",
                            "BLW05A", "BLW05B",
                            "BLW06A", "BLW06B",
                            "BLW07A", "BLW07B",
                            "BLW08A", "BLW08B",
                            "BLW09A", "BLW09B"), 
                   ncol = 2, byrow = T)

attach(il.data)

for(core in 1:length(il.pairs[,1])){
  il.corrs[core, ] <- c("IL", il.pairs[core, 1], il.pairs[core, 2],
                        round(pairwise.corr(il.data[, il.pairs[core,1]], 
                                            il.data[, il.pairs[core,2]], 
                                            tmean, ppt), digits = 4))
}

detach(il.data)



## 9 Missouri

mo.pairs <- matrix(data = c("BAB021", "BAB022",
                            "BAB031", "BAB032",
                            "BAB041", "BAB042",
                            "BAB051", "BAB052",
                            "BAB061", "BAB062",
                            "BAB071", "BAB072",
                            "BAB081", "BAB082",
                            "BAB091", "BAB092",
                            "BAB101", "BAB102",
                            "BAB111", "BAB112",
                            "BAB121", "BAB122",
                            "BAB131", "BAB132",
                            "BAB141", "BAB142",
                            "BAB161", "BAB162",
                            "BAB171", "BAB172",
                            "BAB181", "BAB182",
                            "BAB191", "BAB192",
                            "BAB201", "BAB202",
                            "BAB211", "BAB212",
                            "BAB221", "BAB222",
                            "BAB231", "BAB232",
                            "BAB241", "BAB242",
                            "BAB261", "BAB262",
                            "BAB281", "BAB282",
                            "BAB291", "BAB292",
                            "BAB301", "BAB302",
                            "BAB311", "BAB312",
                            "SBA02A", "SBA02B",
                            "SBA03A", "SBA03B",
                            "SBA04A", "SBA04B",
                            "SBA05A", "SBA05B",
                            "SBA06A", "SBA06B",
                            "SBA07A", "SBA07B",
                            "SBA08A", "SBA08B",
                            "SBA10A", "SBA10B",
                            "SBA11A", "SBA11B",
                            "SBA12A", "SBA12B",
                            "SBA13A", "SBA13B",
                            "SBA14A", "SBA14B",
                            "SBA15A", "SBA15B"), 
                   ncol = 2, byrow = T)

attach(mo.data)

for(core in 1:length(mo.pairs[,1])){
  mo.corrs[core, ] <- c("MO", mo.pairs[core, 1], mo.pairs[core, 2],
                        round(pairwise.corr(mo.data[, mo.pairs[core,1]], 
                                            mo.data[, mo.pairs[core,2]], 
                                            tmean, ppt), digits = 4))
}

detach(mo.data)



## 10 New York

ny.pairs <- matrix(data = c("TVW01a", "TVW01b",
                            "TVW02a", "TVW02b",
                            "TVW03a", "TVW03b",
                            "TVW04a", "TVW04b",
                            "TVW06a", "TVW06b",
                            "TVW07a", "TVW07b",
                            "TVW09a", "TVW09b",
                            "TVW10a", "TVW10b",
                            "TVW11a", "TVW11b",
                            "TVW12a", "TVW12b",
                            "TVW16a", "TVW16b",
                            "TVW17a", "TVW17b",
                            "TVW18a", "TVW18b",
                            "TVW19a", "TVW19b"), 
                   ncol = 2, byrow = T)

attach(ny.data)

for(core in 1:length(ny.pairs[,1])){
  ny.corrs[core, ] <- c("NY", ny.pairs[core, 1], ny.pairs[core, 2],
                        round(pairwise.corr(ny.data[, ny.pairs[core,1]], 
                                            ny.data[, ny.pairs[core,2]], 
                                            tmean, ppt), digits = 4))
}

detach(ny.data)




## 11 Combine all correlation data and save

(all.corrs <- rbind(ia.corrs, il.corrs, in.corrs, mo.corrs, 
                    nc.corrs, ny.corrs, oh.corrs, wi.corrs))
all.corrs[,4:12] <- lapply(all.corrs[,4:12], as.numeric)

comment(all.corrs) <- paste("Correlations b/w tree cores and climate / ", 
                            filename, 
                          "/ NWB / 2024-10-05", sep = "")

saveRDS(all.corrs, paste("Data/", filename, ".RDS", sep = ""))


# close log
sink()


